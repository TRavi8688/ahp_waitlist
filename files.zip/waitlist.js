// api/waitlist.js — Vercel Serverless Function
// POST /api/waitlist — saves a signup to Neon DB + sends confirmation email via EmailJS

import { neon } from "@neondatabase/serverless";

export default async function handler(req, res) {
  // ── CORS headers (allow your Vercel domain)
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(200).end();

  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const { name, email, city, role } = req.body;

    // ── Validate required fields
    if (!email || !email.includes("@")) {
      return res.status(400).json({ error: "Valid email is required." });
    }
    if (!role) {
      return res.status(400).json({ error: "Please select a role." });
    }

    // ── Connect to Neon (inforge.dev) Postgres
    const sql = neon(process.env.DATABASE_URL);

    // ── Create table if it doesn't exist yet
    await sql`
      CREATE TABLE IF NOT EXISTS waitlist_signups (
        id          SERIAL PRIMARY KEY,
        email       TEXT NOT NULL UNIQUE,
        name        TEXT,
        city        TEXT,
        role        TEXT NOT NULL,
        signed_up_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        referral    TEXT
      )
    `;

    // ── Insert (ignore duplicates gracefully)
    const existing = await sql`
      SELECT id FROM waitlist_signups WHERE email = ${email.toLowerCase().trim()}
    `;

    if (existing.length > 0) {
      // Already signed up — still return success so UX is smooth
      const countRow = await sql`SELECT COUNT(*) as count FROM waitlist_signups`;
      return res.status(200).json({
        success: true,
        alreadySignedUp: true,
        count: parseInt(countRow[0].count),
      });
    }

    await sql`
      INSERT INTO waitlist_signups (email, name, city, role)
      VALUES (
        ${email.toLowerCase().trim()},
        ${name?.trim() || null},
        ${city?.trim() || null},
        ${role}
      )
    `;

    // ── Get updated count
    const countRow = await sql`SELECT COUNT(*) as count FROM waitlist_signups`;
    const count = parseInt(countRow[0].count);

    // ── Send confirmation email via EmailJS REST API
    // EmailJS is called server-side so your service ID/template ID stay safe
    try {
      await fetch("https://api.emailjs.com/api/v1.0/email/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          service_id: process.env.EMAILJS_SERVICE_ID,
          template_id: process.env.EMAILJS_TEMPLATE_ID,
          user_id: process.env.EMAILJS_PUBLIC_KEY,
          accessToken: process.env.EMAILJS_PRIVATE_KEY,
          template_params: {
            to_name: name || "there",
            to_email: email.toLowerCase().trim(),
            user_role: role,
            user_city: city || "your city",
            waitlist_count: count,
          },
        }),
      });
    } catch (emailErr) {
      // Email failure shouldn't break signup — log but continue
      console.error("EmailJS error:", emailErr);
    }

    return res.status(200).json({ success: true, count });
  } catch (err) {
    console.error("Waitlist error:", err);
    return res.status(500).json({ error: "Something went wrong. Please try again." });
  }
}
