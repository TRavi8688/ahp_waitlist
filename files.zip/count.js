// api/count.js — Vercel Serverless Function
// GET /api/count — returns real waitlist count from Neon DB

import { neon } from "@neondatabase/serverless";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  if (req.method === "OPTIONS") return res.status(200).end();

  if (req.method !== "GET") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const sql = neon(process.env.DATABASE_URL);

    // Table might not exist yet if no one has signed up
    const result = await sql`
      SELECT COUNT(*) as count
      FROM waitlist_signups
    `.catch(() => [{ count: "0" }]);

    const count = parseInt(result[0]?.count || "0");
    return res.status(200).json({ count });
  } catch (err) {
    console.error("Count error:", err);
    return res.status(200).json({ count: 0 });
  }
}
