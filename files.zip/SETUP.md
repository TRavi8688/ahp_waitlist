# AHP — AI Health Passport: Full-Stack Setup Guide

## 📁 Project Structure

```
ahp-project/
├── api/
│   ├── waitlist.js     ← POST /api/waitlist  (save signup + send email)
│   └── count.js        ← GET  /api/count     (return real waitlist count)
├── index.html          ← Your landing page (updated with real API calls)
├── package.json
├── vercel.json
├── .env.example        ← Copy this to .env and fill in your credentials
└── .gitignore
```

---

## STEP 1 — Get your Neon / Inforge.dev connection string

1. Go to your inforge.dev dashboard
2. Open your project → **Connection Details**
3. Copy the **Connection String** — it looks like:
   ```
   postgresql://alex:password@ep-cool-name.us-east-2.aws.neon.tech/neondb?sslmode=require
   ```
4. Paste it as `DATABASE_URL` in your `.env` file

> ✅ The table (`waitlist_signups`) is created **automatically** on the first signup — you don't need to run any SQL manually.

---

## STEP 2 — Set up EmailJS (confirmation email)

### A. Create an Email Template in EmailJS

1. Go to [emailjs.com](https://emailjs.com) → **Email Templates** → **Create New Template**
2. Use this template content:

**Subject:** `You're on the AHP waitlist! 🎉`

**Body:**
```
Hi {{to_name}},

Welcome to AHP — AI Health Passport! 🏥

You've successfully joined our waitlist as a {{user_role}} from {{user_city}}.

You're now among {{waitlist_count}} people who believe health records should be simple, secure, and patient-owned.

What happens next?
→ We'll email you when early access opens
→ Founders on the waitlist get lifetime free tier + priority onboarding
→ Your feedback will directly shape the product

Share AHP with a doctor or patient friend — the more people join, the faster we build:
https://ahp.health

Stay healthy,
The AHP Team ⚕️
```

3. Note down your **Template ID** (e.g. `template_abc123`)

### B. Get your EmailJS Keys

Go to **Account** → **API Keys**:
- **Public Key** → `EMAILJS_PUBLIC_KEY`
- **Private Key** → `EMAILJS_PRIVATE_KEY`

Go to **Email Services** → your service:
- **Service ID** → `EMAILJS_SERVICE_ID`

---

## STEP 3 — Set up your .env file

```bash
cp .env.example .env
```

Fill in all values:
```env
DATABASE_URL=postgresql://user:pass@host/db?sslmode=require
EMAILJS_SERVICE_ID=service_xxxxxxx
EMAILJS_TEMPLATE_ID=template_xxxxxxx
EMAILJS_PUBLIC_KEY=xxxxxxxxxxxxxxxxxxxx
EMAILJS_PRIVATE_KEY=xxxxxxxxxxxxxxxxxxxx
```

---

## STEP 4 — Deploy to Vercel

### Option A: Using Vercel CLI (recommended)

```bash
# Install dependencies
npm install

# Install Vercel CLI globally
npm install -g vercel

# Login to Vercel
vercel login

# Deploy (first time — follow the prompts)
vercel

# Add your environment variables
vercel env add DATABASE_URL
vercel env add EMAILJS_SERVICE_ID
vercel env add EMAILJS_TEMPLATE_ID
vercel env add EMAILJS_PUBLIC_KEY
vercel env add EMAILJS_PRIVATE_KEY

# Deploy to production
vercel --prod
```

### Option B: Via Vercel Dashboard (no CLI needed)

1. Push this project to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → **New Project** → Import your repo
3. Go to **Settings → Environment Variables**
4. Add all 5 variables from your `.env` file
5. Click **Redeploy**

---

## STEP 5 — Verify it works

After deploying, test these URLs in your browser:

- `https://your-app.vercel.app/` → Should show your landing page
- `https://your-app.vercel.app/api/count` → Should return `{"count": 0}`

Then submit the waitlist form — you should:
1. ✅ See the success screen
2. ✅ See the count increment
3. ✅ Receive a confirmation email
4. ✅ See the row in your Neon/Inforge DB

---

## Database Schema (for reference)

The table is auto-created. Here's what it looks like:

```sql
CREATE TABLE waitlist_signups (
  id            SERIAL PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE,
  name          TEXT,
  city          TEXT,
  role          TEXT NOT NULL,          -- 'patient' | 'doctor' | 'hospital' | 'investor'
  signed_up_at  TIMESTAMPTZ DEFAULT NOW(),
  referral      TEXT                    -- for future referral tracking
);
```

To view all signups, run in your Neon console:
```sql
SELECT * FROM waitlist_signups ORDER BY signed_up_at DESC;
```

---

## What changed in index.html

The following JavaScript was replaced with real API calls:

| Before | After |
|--------|-------|
| Fake counter animating randomly | `GET /api/count` loads real count on page load |
| `submitWaitlist()` just showed success UI | `POST /api/waitlist` saves to DB + triggers email |
| `localStorage` only | DB is source of truth; localStorage just for UX |
| No loading state | Button shows "Reserving your spot…" while submitting |
| No error handling | Inline error messages if something fails |

---

## Questions?

The two EmailJS env vars you might not have yet are the **Private Key** and the **Template ID**.
The private key is needed because we call EmailJS from the server (not the browser) — this keeps it secure.
